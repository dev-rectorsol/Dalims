<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" lang="en">

<!-- Mirrored from www.dalimsssunbeam.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 07 Dec 2020 08:47:38 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->

<head>
    <link rel="apple-touch-icon" sizes="57x57" href="FAVI/apple-icon-57x57.html" />
    <link rel="apple-touch-icon" sizes="60x60" href="FAVI/apple-icon-60x60.html" />
    <link rel="apple-touch-icon" sizes="72x72" href="FAVI/apple-icon-72x72.html" />
    <link rel="apple-touch-icon" sizes="76x76" href="FAVI/apple-icon-76x76.html" />
    <link rel="apple-touch-icon" sizes="114x114" href="FAVI/apple-icon-114x114.html" />
    <link rel="apple-touch-icon" sizes="120x120" href="FAVI/apple-icon-120x120.html" />
    <link rel="apple-touch-icon" sizes="144x144" href="FAVI/apple-icon-144x144.html" />
    <link rel="apple-touch-icon" sizes="152x152" href="FAVI/apple-icon-152x152.html" />
    <link rel="apple-touch-icon" sizes="180x180" href="FAVI/apple-icon-180x180.html" />
    <link rel="icon" type="image/png" sizes="192x192" href="FAVI/android-icon-192x192.html" />
    <link rel="icon" type="image/png" sizes="32x32" href="FAVI/favicon-32x32.html" />
    <link rel="icon" type="image/png" sizes="96x96" href="FAVI/favicon-96x96.html" />
    <link rel="icon" type="image/png" sizes="16x16" href="FAVI/favicon-16x16.html" />
    <link rel="manifest" href="FAVI/manifest.html" />
    <meta name="msapplication-TileColor" content="#ffffff" />
    <meta name="msapplication-TileImage" content="FAVI/ms-icon-144x144.html" />
    <meta name="theme-color" content="#ffffff" />
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <meta name="description" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="title" content="Best CBSE Schools in Varanasi" />
    <meta name="title" content="Best CBSE Schools in UP" />
    <meta name="title" content="Best Hostel in Varanai" />
    <meta name="title" content="Saperate Hostel for boys &amp; Girls" />
    <meta name="title" content="Best result in board exam" />


    <!-- Primary Meta Tags -->
    <title>
        DALIMSS Sunbeam group of Schools: Best School of Varanasi : Official Website
    </title>
    <meta name="title" content="DALIMSS Sunbeam Group of Schools &amp; Hostel, Varanasi : 
Topmost Day &amp; Boarding School, Best in Academics &amp; Facilities, Best CBSE Schools in Varanasi" />
    <meta name="description"
        content="The schools have perfect blend of academics &amp; sports, expert faculty, modern technology, Smart Classrooms, GPS enabled buses, updated Labs &amp; Libraries, Child-sensitive environment, " />

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website" />
    <meta property="og:url" content="index.html" />
    <meta property="og:title" content="DALIMSS Sunbeam Group of Schools &amp; Hostel, Varanasi : 
Topmost Day &amp; Boarding School, Best in Academics &amp; Facilities, Best CBSE Schools in Varanasi" />
    <meta property="og:description"
        content="The schools have perfect blend of academics &amp; sports, expert faculty, modern technology, Smart Classrooms, GPS enabled buses, updated Labs &amp; Libraries, Child-sensitive environment, " />
    <meta property="og:image" />

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image" />
    <meta property="twitter:url" content="index.html" />
    <meta property="twitter:title" content="DALIMSS Sunbeam Group of Schools &amp; Hostel, Varanasi : 
Topmost Day &amp; Boarding School, Best in Academics &amp; Facilities, Best CBSE Schools in Varanasi" />
    <meta property="twitter:description"
        content="The schools have perfect blend of academics &amp; sports, expert faculty, modern technology, Smart Classrooms, GPS enabled buses, updated Labs &amp; Libraries, Child-sensitive environment, " />
    <meta property="twitter:image" />
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->



    <!-- Google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i" rel="stylesheet" />


    <!--====== Slick css ======-->
    <link rel="stylesheet" href="<?php echo base_url('')?>assets/css/slick.css" />

    <!--====== Animate css ======-->
    <link rel="stylesheet" href="<?php echo base_url('')?>assets/css/animate.css" />

    <!--====== Nice Select css ======-->
    <link rel="stylesheet" href="<?php echo base_url('')?>assets/css/nice-select.css" />

    <!--====== Nice Number css ======-->
    <link rel="stylesheet" href="<?php echo base_url('')?>assets/css/jquery.nice-number.min.css" />

    <!--====== Magnific Popup css ======-->
    <link rel="stylesheet" href="<?php echo base_url('')?>assets/css/magnific-popup.css" />

    <!--====== Bootstrap css ======-->
    <link rel="stylesheet" href="<?php echo base_url('')?>assets/css/bootstrap.min.css" />

    <!--====== Fontawesome css ======-->
    <link rel="stylesheet" href="<?php echo base_url('')?>assets/css/font-awesome.min.css" />

    <!--====== Default css ======-->
    <link rel="stylesheet" href="<?php echo base_url('')?>assets/css/default.css" />

    <!--====== Style css ======-->
    <link rel="stylesheet" href="<?php echo base_url('')?>assets/css/style.css" />

    <!--====== Responsive css ======-->
    <link rel="stylesheet" href="<?php echo base_url('')?>assets/css/responsive.css" />
</head>