<body>


    <!--====== PRELOADER PART START ======-->

    <div class="preloader">
        <div class="loader rubix-cube">
            <div class="layer layer-1"></div>
            <div class="layer layer-2"></div>
            <div class="layer layer-3 color-1"></div>
            <div class="layer layer-4"></div>
            <div class="layer layer-5"></div>
            <div class="layer layer-6"></div>
            <div class="layer layer-7"></div>
            <div class="layer layer-8"></div>
        </div>
    </div>

    <!--====== PRELOADER PART START ======-->

    <!--====== HEADER PART START ======-->

    <header id="header-part">
        <div class="header-top d-none d-lg-block">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="header-contact">
                            <ul>
                                <li><i class="fa fa-envelope"></i><a href="#">info@dalimsssunbeam.com</a></li>
                                <li><i class="fa fa-phone"></i><span>+91-7800552277</span></li>
                            </ul>
                        </div>
                        <!-- header contact -->
                    </div>
                    <div class="col-md-6">
                        <div class="header-right d-flex justify-content-end">
                            <div class="social d-flex">
                                <span class="follow-us">Follow Us :</span>
                                <ul>
                                    <li><a href="https://www.facebook.com/dalimsssunbeamschools/"><i class="fa fa-facebook-f"></i></a></li>
                                    <li><a href="https://www.youtube.com/channel/UC_eE2jxedqYK3wjiYbHEchw?view_as=subscriber"><i class="fa fa-youtube"></i></a></li>
                                    <li><a href="https://twitter.com/Dalimss_sunbeam"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="https://www.instagram.com/dalimsssunbeamschools/"><i class="fa fa-instagram"></i></a></li>
                                    <li><a href="https://www.linkedin.com/in/dalimss-sunbeam-school-647666177/"><i class="fa fa-linkedin"></i></a></li>
                                </ul>
                            </div>
                            <!-- social -->
                            <div class="login-register">
                                <ul>

                                   

                                </ul>
                            </div>
                        </div>
                        <!-- header right -->
                    </div>
                </div>
                <!-- row -->
            </div>
            <!-- container -->
        </div>
        <!-- header top -->

        <div class="navigation">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <nav class="navbar navbar-expand-lg">
                            <a class="navbar-brand" href="#">
                                <img src="<?php echo base_url() ?>assets/images/logo.png" alt="Logo">
                            </a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>

                            <div class="collapse navbar-collapse sub-menu-bar" id="navbarSupportedContent">
                                <ul class="navbar-nav ml-auto">
                                    <li class="nav-item">
                                        <a class="active" href="#">Home</a>
                                    </li>

                                    <li class="nav-item">
                                        <a href="#">About</a>

                                        <ul class="sub-menu">

                                            <li>
                                                <a href="#">About The School/Group</a></li>
                                            <li><a href="#">Mission</a></li>
                                            <li><a href="#">Vision</a></li>
                                            <li><a href="#">Member's Message</a></li>
                                            <li><a href="#">Location</a></li>
                                            <li><a href="#">Facilities</a></li>
                                            <li><a href="#">Photo Gallery</a></li>
                                            <li><a href="#">Download Gallery</a></li>

                                        </ul>

                                    </li>



                                    <li class="nav-item">
                                        <a href="#">Campus</a>
                                        <ul class="sub-menu">
                                            <li><a href="#">Rohania</a></li>
                                            <li><a href="#">Sigra</a></li>
                                            <li><a href="#">Ramkatora</a></li>
                                            <li><a href="#">Toddlers N Kids , Ramkatora</a></li>
                                            <li><a href="#">Paharia</a></li>
                                            <li><a href="#">Mahmoorganj</a></li>
                                            <li><a href="#">NTPC Tanda</a></li>
                                        </ul>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#">Admission</a>
                                        <ul class="sub-menu">
                                            <li><a href="#">Prospectus</a></li>
                                            <li><a href="#">Admission Procedure</a></li>
                                            <li><a href="#">Eligeblity</a></li>
                                            <li><a href="#">Enquiry Form</a></li>
                                            <li><a href="#">Download TC</a></li>
                                        </ul>
                                    </li>



                                    <li class="nav-item">
                                        <a href="#">Academics</a>
                                        <ul class="sub-menu">
                                            <li>
                                                <a href="#">Overview</a> </li>
                                            <li><a href="#">Library</a> </li>
                                            <li><a href="#">Labs</a> </li>
                                            <li><a href="#">Clubs</a> </li>
                                            <li><a href="#">Sports</a> </li>
                                            <li><a href="#">Boarding School</a> </li>
                                            <li><a href="#">NIOS</a>

                                            </li>
                                            <li>


                                                

                                                <li><a href="#">Tooppers List Class X</a> </li>
                                                <li><a href="#">Tooppers List Class XII</a>

                                                </li>
                                        </ul>
                                    </li>





                                    <li class="nav-item">
                                        <a href="#">Disclosure</a>
                                        <ul class="sub-menu">
                                            <li>
                                                <a href="#">Affiliation</a></li>
                                            <li><a href="#">Establishment</a></li>
                                            <li><a href="#">NOC From State</a></li>
                                            <li><a href="#">Status Of Affiliation</a></li>
                                            <li><a href="#">Trust/Society/<br />
                                                company</a>

                                            </li>
                                            <li>
                                                <a href="#">Vacation Period</a></li>
                                            <li><a href="#">List Of Members</a></li>
                                            <li><a href="#">Official Address</a></li>
                                            <li><a href="#">Infrastructure</a></li>
                                            <li><a href="#">Transport Facility</a>
                                            </li>

                                            <li>
                                                <a href="#">Teaching Staff</a></li>
                                            <li><a href="#">Grievance/<br />
                                                Redressal</a></li>
                                            <li><a href="#">Sexual Harassment Commitiee</a></li>
                                            <li><a href="#">Section Wise Enrolment</a></li>
                                            <li><a href="#">Academic Session Period</a>

                                            </li>
                                        </ul>
                                    </li>

                                    <li class="nav-item">
                                        <a href="#">Events</a>
                                        <ul class="sub-menu">
                                            <li><a href="#">Latest News</a></li>
                                            <li><a href="#">Upcoming Events</a></li>




                                            <li><a href="#">Press Release</a> </li>
                                            <li><a href="#">Spectrum</a></li>


                                            <li><a href="#">CBSE HOCKEY NATIONAL 2019</a></li>
                                            <li><a href="#">CBSE VOLLYBALL NATIONAL 2017</a></li>

                                        </ul>
                                    </li>

                                    <li class="nav-item">
                                        <a href="#">Career</a>
                                    </li>



                                    <li class="nav-item">
                                        <a href="#">Contact</a>

                                    </li>
                                </ul>
                            </div>

                            <!-- right icon -->
                        </nav>
                        <!-- nav -->
                    </div>
                </div>
                <!-- row -->
            </div>
            <!-- container -->
        </div>
    </header>