

    <!--====== jquery js ======-->
    <script src="<?php echo base_url('')?>assets/js/vendor/modernizr-3.6.0.min.js"></script>
    <script src="<?php echo base_url('')?>assets/js/vendor/jquery-1.12.4.min.js"></script>

    <!--====== Bootstrap js ======-->
    <script src="<?php echo base_url('')?>assets/js/bootstrap.min.js"></script>

    <!--====== Slick js ======-->
    <script src="<?php echo base_url('')?>assets/js/slick.min.js"></script>

    <!--====== Magnific Popup js ======-->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>

    <!--====== Counter Up js ======-->
    <script src="<?php echo base_url('')?>assets/js/waypoints.min.js"></script>
    <script src="<?php echo base_url('')?>assets/js/jquery.counterup.min.js"></script>

    <!--====== Nice Select js ======-->
    <script src="<?php echo base_url('')?>assets/js/jquery.nice-select.min.js"></script>

    <!--====== Nice Number js ======-->
    <script src="<?php echo base_url('')?>assets/js/jquery.nice-number.min.js"></script>

    <!--====== Count Down js ======-->
    <script src="<?php echo base_url('')?>assets/js/jquery.countdown.min.js"></script>

    <!--====== Validator js ======-->
    <script src="<?php echo base_url('')?>assets/js/validator.min.js"></script>

    <!--====== Ajax Contact js ======-->
    <script src="<?php echo base_url('')?>assets/js/ajax-contact.js"></script>

    <!--====== Main js ======-->
    <script src="<?php echo base_url('')?>assets/js/main.js"></script>



    <div id="fb-root"></div>
    <script>(function (d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s); js.id = id;
    js.src = '<?php echo base_url() ?>assets/js/sdk.js#xfbml=1&version=v3.1&appId=1791027434519813&autoLogAppEvents=1';
    fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
    <!-- Main Body Area End Here -->

    <a class="page-scroll scroll-top" href="#scroll-top"><i class="fa fa-angle-up" aria-hidden="true"></i></a>
    <!-- Footer End here -->

    <script>
        (function (i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r; i[r] = i[r] || function () {
                (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date(); a = s.createElement(o),
            m = s.getElementsByTagName(o)[0]; a.async = 1; a.src = g; m.parentNode.insertBefore(a, m)
        })(window, document, 'script', '<?php echo base_url() ?>assets/js/analytics.js', 'ga');

        ga('create', 'UA-83751913-1', 'auto');
        ga('send', 'pageview');

    </script>


    

    <!--Start of Tawk.to Script-->
    <script type="text/javascript">
        var Tawk_API = Tawk_API || {}, Tawk_LoadStart = new Date();
        (function () {
            var s1 = document.createElement("script"), s0 = document.getElementsByTagName("script")[0];
            s1.async = true;
            s1.src = 'https://embed.tawk.to/583bd6f8f9976a1964bd7658/default';
            s1.charset = 'UTF-8';
            s1.setAttribute('crossorigin', '*');
            s0.parentNode.insertBefore(s1, s0);
        })();
    </script>
    <!--End of Tawk.to Script-->

    
</body>

<!-- Mirrored from www.dalimsssunbeam.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 07 Dec 2020 08:55:05 GMT -->
</html>
