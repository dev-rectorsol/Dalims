<?php include ('layout/css.php')?>
<?php include ('layout/nav.php')?>
<?php echo $main?>

<?php include ('layout/footer.php')?>
<?php include ('layout/js.php')?>