<form name="aspnetForm" method="post" action="http://www.dalimsssunbeam.com/Index.aspx" id="aspnetForm">
    <div>
        <input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
        <input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
        <input type="hidden" name="__LASTFOCUS" id="__LASTFOCUS" value="" />
        <input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE"
            value="/wEPDwUKLTE5OTg0MTgzNA9kFgJmD2QWAgIDD2QWAgIDD2QWBgIDD2QWAmYPZBYCAgEPEGRkFgFmZAIHDzwrAAkBAA8WBB4IRGF0YUtleXMWAB4LXyFJdGVtQ291bnQCA2QWBmYPZBYCZg8VBwIxMANTZXAEMjAyMA5Gb3VuZGF0aW9uIERheQAABVNpZ3JhZAIBD2QWAmYPFQcBNANTZXAEMjAyMAhTdXBlciAyMAYmbmJzcDsGJm5ic3A7BiZuYnNwO2QCAg9kFgJmDxUHATQDQXByBDIwMjAbR2VuaXVzIDExIFNjaG9sYXJzaGlwIEV4YW0gCDA5OjMwIGFtBzAxOjMwcG0XREFMSU1TUyBTVU5CRUFNIFJPSEFOSUFkAgkPPCsACQEADxYEHwAWAB8BAgZkFgxmD2QWBAIBDw8WAh4ISW1hZ2VVcmwFRmh0dHA6Ly93d3cuZGFsaW1zc3N1bmJlYW0uY29tL0FkbWluX1BhbmVsL1NDSE9PTF9CVUlMRElOR1Mvcm9oYW5pYS5qcGdkZAIDDw8WBB4PQ29tbWFuZEFyZ3VtZW50BQdST0hBTklBHgRUZXh0BQdST0hBTklBZGQCAQ9kFgQCAQ8PFgIfAgVIaHR0cDovL3d3dy5kYWxpbXNzc3VuYmVhbS5jb20vQWRtaW5fUGFuZWwvU0NIT09MX0JVSUxESU5HUy9yYW1rYXRvcmEuanBnZGQCAw8PFgQfAwUJUkFNS0FUT1JBHwQFCVJBTUtBVE9SQWRkAgIPZBYEAgEPDxYCHwIFRGh0dHA6Ly93d3cuZGFsaW1zc3N1bmJlYW0uY29tL0FkbWluX1BhbmVsL1NDSE9PTF9CVUlMRElOR1Mvc2lncmEuanBnZGQCAw8PFgQfAwUFU0lHUkEfBAUFU0lHUkFkZAIDD2QWBAIBDw8WAh8CBUlodHRwOi8vd3d3LmRhbGltc3NzdW5iZWFtLmNvbS9BZG1pbl9QYW5lbC9TQ0hPT0xfQlVJTERJTkdTL21vaGluaWt1bmouanBnZGQCAw8PFgQfAwUKTU9ISU5JS1VOSh8EBQpNT0hJTklLVU5KZGQCBA9kFgQCAQ8PFgIfAgVGaHR0cDovL3d3dy5kYWxpbXNzc3VuYmVhbS5jb20vQWRtaW5fUGFuZWwvU0NIT09MX0JVSUxESU5HUy9wYWhhcmlhLmpwZ2RkAgMPDxYEHwMFB1BBSEFSSUEfBAUHUEFIQVJJQWRkAgUPZBYEAgEPDxYCHwIFQ2h0dHA6Ly93d3cuZGFsaW1zc3N1bmJlYW0uY29tL0FkbWluX1BhbmVsL1NDSE9PTF9CVUlMRElOR1MvbnRwYy5qcGdkZAIDDw8WBB8DBQpOVFBDIFRBTkRBHwQFCk5UUEMgVEFOREFkZGT5fmJm+m2eZSseyCxa1X+FRUJsuA==" />
    </div>

    <script type="text/javascript">
    //<![CDATA[
    var theForm = document.forms['aspnetForm'];
    if (!theForm) {
        theForm = document.aspnetForm;
    }

    function __doPostBack(eventTarget, eventArgument) {
        if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
            theForm.__EVENTTARGET.value = eventTarget;
            theForm.__EVENTARGUMENT.value = eventArgument;
            theForm.submit();
        }
    }
    //]]>
    </script>


    <script
        src="<?php echo base_url() ?>assets/js/WebResourcefbe9.js?d=5wuaTIAQ-tR9Dd0N0oX0u5D9Ty7R-HgHOKstIiWuZ8SNHmug1qTQg_OKoNBGoCxidpQ-htpgaVDCqQra2G8qbogQSIM1&amp;t=637292063023430478"
        type="text/javascript"></script>


    <script
        src="<?php echo base_url() ?>assets/js/ScriptResourcefdd7.js?d=bJQl3AHyf3Sf4qpNY9FDUcD_RiK24zSEr5TgWn4-Pta5JhvErxJCb-R3To_bHZ04ljNAw6kUhp5nHcViaQgiVVeMECdD8LPK7plkZlVQ4fdfGFWa2vWx4vfToEfQjfkakVPOw7MJYy7-hj3bfaGrcHb5eH1Jvke_3MYSW_XkrfKn4Nxh0&amp;t=3f4a792d"
        type="text/javascript"></script>
    <script type="text/javascript">
    //<![CDATA[
    if (typeof(Sys) === 'undefined') throw new Error('ASP.NET Ajax client-side framework failed to load.');
    //]]>
    </script>

    <script
        src="<?php echo base_url() ?>assets/js/ScriptResource3966.js?d=89NUju3xFQHQunrb0ee1DYSoi8kt5D4ln5aDjAOsbt2fH5HvlVmE3qHJ7rqVgykkLo41pn_BglskUHQj8M3ZHpiMSwK4MEbzXbuQ18bI2aFcCcEXO_RJPjP2vTp7jiUaJJ55fVPfpkTtLSVXDNUk8SS0pfLNhkHMM2mMJKhvN5f7qUfX0&amp;t=3f4a792d"
        type="text/javascript"></script>
    <div>

        <input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="90059987" />
        <input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION"
            value="/wEWDALpm8bICALe29n2BgL54OrjDQK9m4m7BwKaqs+KDQL40JWDCgL3k46XAgKYm5CXAgK5xZKXAgLayoOXAgL7tJaXAgKcvLj+AcbbLHIPFs3SGl4KqymPcVOxGxXZ" />
    </div>
    <script type="text/javascript">
    //<![CDATA[
    Sys.WebForms.PageRequestManager._initialize('ctl00$ScriptManager1', document.getElementById('aspnetForm'));
    Sys.WebForms.PageRequestManager.getInstance()._updateControls(['tctl00$ContentPlaceHolder1$UpdatePanel1'], [], [],
        90);
    //]]>
    </script>



    <!-- Slider 1 Area Start Here -->


    <!--====== SLIDER PART START ======-->

    <section id="slider-part" class="slider-active">
        <div class="single-slider slider-4 bg_cover pt-150" style="background-image: url(<?php echo base_url() ?>assets/images/slider/banner_03.jpg)">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-7 col-lg-9">
                        <div class="slider-cont slider-cont-4 text-center">


                        </div>
                    </div>
                </div>
                <!-- row -->
            </div>
            <!-- container -->
        </div>
        <!-- single slider -->

        <div class="single-slider slider-4 bg_cover pt-150" style="background-image: url(<?php echo base_url() ?>assets/images/slider/banner_08.jpg)">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-7 col-lg-9">
                        <div class="slider-cont slider-cont-4 text-center">


                        </div>
                    </div>
                </div>
                <!-- row -->
            </div>
            <!-- container -->
        </div>
        <!-- single slider -->


        <div class="single-slider slider-4 bg_cover pt-150" style="background-image: url(<?php echo base_url() ?>assets/images/slider/banner_09.jpg)">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-7 col-lg-9">
                        <div class="slider-cont slider-cont-4 text-center">


                        </div>
                    </div>
                </div>
                <!-- row -->
            </div>
            <!-- container -->
        </div>
        <!-- single slider -->

        <div class="single-slider slider-4 bg_cover pt-150" style="background-image: url(<?php echo base_url() ?>assets/images/slider/banner_12.jpg)">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-7 col-lg-9">
                        <div class="slider-cont slider-cont-4 text-center">


                        </div>
                    </div>
                </div>
                <!-- row -->
            </div>
            <!-- container -->
        </div>
        <!-- single slider -->


        <div class="single-slider slider-4 bg_cover pt-150" style="background-image: url(<?php echo base_url() ?>assets/images/slider/2.jpg)">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-7 col-lg-9">
                        <div class="slider-cont slider-cont-4 text-center">


                        </div>
                    </div>
                </div>
                <!-- row -->
            </div>
            <!-- container -->
        </div>
        <!-- single slider -->


    </section>

    <!--====== SLIDER PART ENDS ======-->






    <!--====== CATEGORY PART START ======-->

    <section id="category-part">
        <div class="container">
            <div class="category pt-40 pb-80">
                <div class="row">
                    <div class="col-lg-6 align-self-xl-center">
                        <div class="category-text pt-40">
                            <h2>ADMISSIONS OPEN FOR SESSION 2020-21</h2>
                            <h2><a href="#" class="main-btn mt-55">CLICK HERE TO REGISTER ONLINE</a>
                            </h2>

                            <br />
                            <br />



                            <span id="ctl00_ContentPlaceHolder1_lblmsg" style="color:Maroon;font-weight:bold;"></span>
                        </div>
                        <br />
                        <hr style="border-color: yellow;" />
                        <br />

                        <center>



                            <div id="ctl00_ContentPlaceHolder1_UpdatePanel1">




                                <div class="text-center">
                                    <h3 style="color:white;"> Admission Enquiry</h3>

                                    <select name="ctl00$ContentPlaceHolder1$ddlscholar"
                                        onchange="javascript:setTimeout('__doPostBack(\'ctl00$ContentPlaceHolder1$ddlscholar\',\'\')', 0)"
                                        id="ctl00_ContentPlaceHolder1_ddlscholar" style="color:Black;">
                                        <option selected="selected" value="---SELECT SCHOOL---">---SELECT SCHOOL---
                                        </option>
                                        <option value="DAY SCHOOL">DAY SCHOOL</option>
                                        <option value="HOSTEL">HOSTEL</option>

                                    </select>
                                    <br />


                                    <select name="ctl00$ContentPlaceHolder1$ddlbranch"
                                        id="ctl00_ContentPlaceHolder1_ddlbranch" style="color:Black;width:200px;">

                                    </select>

                                </div>

                            </div>
                            <br />
                            <br />
                            <input type="submit" name="ctl00$ContentPlaceHolder1$btnsubmit" value="Submit"
                                id="ctl00_ContentPlaceHolder1_btnsubmit" class="btn btn-info" />
                        </center>

                    </div>


                    <div class="col-lg-6" style="align-content: center;">

                        <img src="<?php echo base_url()?>assets/images/Super%2020.jpg" alt="Icon" style="padding: 0 10% 0 10%">
                        <p style="text-align: center;">
                            <span class="cont">
                                <span style="color:white;">DALIMSS Sunbeam School, Varanasi is organising a scholarship
                                    test on Sunday, 20.09.2020 for the students who have passed class X this year. The
                                    selected students will be given scholarships upto 100% waiver on School Composite
                                    Fee.

                                    The registration is free.</span>
                                <a href="#" class="main-btn mt-55">Register </a>

                            </span>
                        </p>



                        <!-- category slide -->
                    </div>
                </div>
                <!-- row -->
            </div>
            <!-- category -->
        </div>
        <!-- container -->
    </section>

    <!--====== CATEGORY PART ENDS ======-->



    <!--====== ABOUT PART START ======-->

    <section id="about-part" class="pt-65">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="section-title mt-50">
                        <h5>About us</h5>
                        <h2>Welcome to DALIMSS SUNBEAM </h2>
                    </div>
                    <!-- section title -->
                    <div class="about-cont">
                        <p>
                            <b>DALIMSS Sunbeam School (Dr. Amrit Lal Ishrat Memorial Sunbeam School) </b>was founded by
                            the Late <b>Mrs. Deesh Ishrat</b> a visionary and educationist, in the memory of
                            distinguished scholar <b>Late Dr. Amrit Lal Ishrat</b>.
                            <br />
                            Today that seed has blossomed into a veritable giant tree of knowledge. The School and its
                            many Branches together testify that under the able guidance and endeavour of<b> Dr. Pradeep
                                'BABA' Madhok - President and Mrs. Pooja Madhok - Director</b>, the school is striding
                            ahead towards a greater growth and development, reiterating its position as the most eminent
                            academic institution in the region.
                            <br />
                            DALIMSS Sunbeam School (Dr. Amrit Lal Ishrat Memorial Sunbeam School) , with branches at
                            <b>ROHANIA, SIGRA,, RAMKATORA, MOHINIKUNJ, PAHARIA, TODDLERS N KIDS (RAMKATORA) </b>is the
                            acknowledged leader amongst academic institutions of Varanasi.
                            <br />
                            A school that upholds the rich Legacy of learning and enviable reputation for excellence
                            that the main branch Rohania is already famous for.

                        </p>
                        <a href="#" class="main-btn mt-55">Learn More</a>
                    </div>
                </div>
                <!-- about cont -->
                <div class="col-lg-5 offset-lg-1">
                    <div class="about-event mt-50">
                        <div class="event-title">
                            <h3>Latest events</h3>
                        </div>
                        <!-- event title -->
                        <ul>
                            <table id="ctl00_ContentPlaceHolder1_dlupcomingevents" cellspacing="0" border="0"
                                style="border-collapse:collapse;">
                                <tr>
                                    <td>

                                        <ul type="none">
                                            <li>


                                                <div class="single-event">
                                                    <span><i class="fa fa-calendar"></i>10 - Sep - 2020</span>
                                                    <a href="#">
                                                        <h4>Foundation Day</h4>
                                                    </a>
                                                    <span><i class="fa fa-clock-o"></i> - </span>
                                                    <span><i class="fa fa-map-marker"></i>Sigra</span>
                                                </div>


                                            </li>
                                        </ul>

                                    </td>
                                </tr>
                                <tr>
                                    <td>

                                        <ul type="none">
                                            <li>


                                                <div class="single-event">
                                                    <span><i class="fa fa-calendar"></i>4 - Sep - 2020</span>
                                                    <a href="#">
                                                        <h4>Super 20</h4>
                                                    </a>
                                                    <span><i class="fa fa-clock-o"></i>&nbsp; - &nbsp;</span>
                                                    <span><i class="fa fa-map-marker"></i>&nbsp;</span>
                                                </div>


                                            </li>
                                        </ul>

                                    </td>
                                </tr>
                                <tr>
                                    <td>

                                        <ul type="none">
                                            <li>


                                                <div class="single-event">
                                                    <span><i class="fa fa-calendar"></i>4 - Apr - 2020</span>
                                                    <a href="#">
                                                        <h4>Genius 11 Scholarship Exam </h4>
                                                    </a>
                                                    <span><i class="fa fa-clock-o"></i>09:30 am - 01:30pm</span>
                                                    <span><i class="fa fa-map-marker"></i>DALIMSS SUNBEAM ROHANIA</span>
                                                </div>


                                            </li>
                                        </ul>

                                    </td>
                                </tr>
                            </table>

                            <a href="#" class="view-all-primary-btn">View All</a>


                            <li></li>

                        </ul>
                    </div>
                    <!-- about event -->
                </div>
            </div>
            <!-- row -->
        </div>
        <!-- container -->
        <div class="about-bg">
            <img src="<?php echo base_url() ?>assets/images/about/bg-1.html" alt="About">
        </div>
    </section>

    <!--====== ABOUT PART ENDS ======-->

    <!--====== BRANCH PART START ======-->

    <section id="Section2" class="pt-115 pb-115 bg_cover gray-bg"
        style="background-image: url(<?php echo base_url() ?>assets/images/course/course-shape.png)">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="section-title pb-45">
                        <h5>Our Branches</h5>

                    </div>
                    <!-- section title -->
                </div>
            </div>
            <!-- row -->
            <div class="row featuredContainer">



                <span id="ctl00_ContentPlaceHolder1_DataList1"><span
                        style="display:inline-block;height:300px;width:400px;">

                        <div class="col-lg-12" id="dls1">
                            <div class="single-course-2 mt-30">
                                <div class="thum">
                                    <div class="image">
                                        <img id="ctl00_ContentPlaceHolder1_DataList1_ctl00_Image1"
                                            class="img-responsive" src="<?php echo base_url()?>assets/images/SCHOOL_BUILDINGS/rohania.jpg"
                                            style="border-width:0px;" />
                                    </div>

                                    <div class="course-teacher d-flex align-items-center">

                                        <div class="teacher ml-10">
                                            <div class="name">
                                                <a href="#">
                                                    <h6>
                                                        <a id="ctl00_ContentPlaceHolder1_DataList1_ctl00_LinkButton1"
                                                            href="javascript:__doPostBack('ctl00$ContentPlaceHolder1$DataList1$ctl00$LinkButton1','')">ROHANIA</a>
                                                </a></h6>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                            </div>
                            <!-- single course -->
                        </div>

                    </span><span style="display:inline-block;height:300px;width:400px;">

                        <div class="col-lg-12" id="dls1">
                            <div class="single-course-2 mt-30">
                                <div class="thum">
                                    <div class="image">
                                        <img id="ctl00_ContentPlaceHolder1_DataList1_ctl01_Image1"
                                            class="img-responsive" src="<?php echo base_url()?>assets/images/SCHOOL_BUILDINGS/ramkatora.jpg"
                                            style="border-width:0px;" />
                                    </div>

                                    <div class="course-teacher d-flex align-items-center">

                                        <div class="teacher ml-10">
                                            <div class="name">
                                                <a href="#">
                                                    <h6>
                                                        <a id="ctl00_ContentPlaceHolder1_DataList1_ctl01_LinkButton1"
                                                            href="javascript:__doPostBack('ctl00$ContentPlaceHolder1$DataList1$ctl01$LinkButton1','')">RAMKATORA</a>
                                                </a></h6>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                            </div>
                            <!-- single course -->
                        </div>

                    </span><span style="display:inline-block;height:300px;width:400px;">

                        <div class="col-lg-12" id="dls1">
                            <div class="single-course-2 mt-30">
                                <div class="thum">
                                    <div class="image">
                                        <img id="ctl00_ContentPlaceHolder1_DataList1_ctl02_Image1"
                                            class="img-responsive" src="<?php echo base_url()?>assets/images/SCHOOL_BUILDINGS/sigra.jpg"
                                            style="border-width:0px;" />
                                    </div>

                                    <div class="course-teacher d-flex align-items-center">

                                        <div class="teacher ml-10">
                                            <div class="name">
                                                <a href="#">
                                                    <h6>
                                                        <a id="ctl00_ContentPlaceHolder1_DataList1_ctl02_LinkButton1"
                                                            href="javascript:__doPostBack('ctl00$ContentPlaceHolder1$DataList1$ctl02$LinkButton1','')">SIGRA</a>
                                                </a></h6>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                            </div>
                            <!-- single course -->
                        </div>

                    </span><br /><span style="display:inline-block;height:300px;width:400px;">

                        <div class="col-lg-12" id="dls1">
                            <div class="single-course-2 mt-30">
                                <div class="thum">
                                    <div class="image">
                                        <img id="ctl00_ContentPlaceHolder1_DataList1_ctl03_Image1"
                                            class="img-responsive" src="<?php echo base_url()?>assets/images/SCHOOL_BUILDINGS/mohinikunj.jpg"
                                            style="border-width:0px;" />
                                    </div>

                                    <div class="course-teacher d-flex align-items-center">

                                        <div class="teacher ml-10">
                                            <div class="name">
                                                <a href="#">
                                                    <h6>
                                                        <a id="ctl00_ContentPlaceHolder1_DataList1_ctl03_LinkButton1"
                                                            href="javascript:__doPostBack('ctl00$ContentPlaceHolder1$DataList1$ctl03$LinkButton1','')">MOHINIKUNJ</a>
                                                </a></h6>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                            </div>
                            <!-- single course -->
                        </div>

                    </span><span style="display:inline-block;height:300px;width:400px;">

                        <div class="col-lg-12" id="dls1">
                            <div class="single-course-2 mt-30">
                                <div class="thum">
                                    <div class="image">
                                        <img id="ctl00_ContentPlaceHolder1_DataList1_ctl04_Image1"
                                            class="img-responsive" src="<?php echo base_url()?>assets/images/SCHOOL_BUILDINGS/paharia.jpg"
                                            style="border-width:0px;" />
                                    </div>

                                    <div class="course-teacher d-flex align-items-center">

                                        <div class="teacher ml-10">
                                            <div class="name">
                                                <a href="#">
                                                    <h6>
                                                        <a id="ctl00_ContentPlaceHolder1_DataList1_ctl04_LinkButton1"
                                                            href="javascript:__doPostBack('ctl00$ContentPlaceHolder1$DataList1$ctl04$LinkButton1','')">PAHARIA</a>
                                                </a></h6>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                            </div>
                            <!-- single course -->
                        </div>

                    </span><span style="display:inline-block;height:300px;width:400px;">

                        <div class="col-lg-12" id="dls1">
                            <div class="single-course-2 mt-30">
                                <div class="thum">
                                    <div class="image">
                                        <img id="ctl00_ContentPlaceHolder1_DataList1_ctl05_Image1"
                                            class="img-responsive" src="<?php echo base_url()?>assets/images/SCHOOL_BUILDINGS/ntpc.html"
                                            style="border-width:0px;" />
                                    </div>

                                    <div class="course-teacher d-flex align-items-center">

                                        <div class="teacher ml-10">
                                            <div class="name">
                                                <a href="#">
                                                    <h6>
                                                        <a id="ctl00_ContentPlaceHolder1_DataList1_ctl05_LinkButton1"
                                                            href="javascript:__doPostBack('ctl00$ContentPlaceHolder1$DataList1$ctl05$LinkButton1','')">NTPC
                                                            TANDA</a>
                                                </a></h6>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                            </div>
                            <!-- single course -->
                        </div>

                    </span><br /></span>

            </div>
            <!-- course slide -->
        </div>
        <!-- container -->
    </section>


    <!--====== BRANCH PART END ======-->


    <!--====== TEACHERS PART START ======-->

    <section id="teachers-part" class="pt-70 pb-120">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                    <div class="section-title mt-50">

                        <h2>Meet Our Pillars</h2>
                    </div>
                    <!-- section title -->
                    <div class="teachers-cont">
                        <p>
                            <b>DALIMSS Sunbeam School (Dr. Amrit Lal Ishrat Memorial Sunbeam School) </b>was founded by
                            the Late <b>Mrs. Deesh Ishrat</b> a visionary and educationist, in the memory of
                            distinguished scholar <b>Late Dr. Amrit Lal Ishrat</b>.
                            <br />
                            Today that seed has blossomed into a veritable giant tree of knowledge. The School and its
                            many Branches together testify that under the able guidance and endeavour of<b> Dr. Pradeep
                                'BABA' Madhok - President and Mrs. Pooja Madhok - Director</b>, the school is striding
                            ahead towards a greater growth and development, reiterating its position as the most eminent
                            academic institution in the region.
                        </p>

                    </div>
                    <!-- teachers cont -->
                </div>
                <div class="col-lg-6 offset-lg-1">
                    <div class="teachers mt-20">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="single-teachers mt-30 text-center">
                                    <div class="image">
                                        <img src="<?php echo base_url()?>assets/img/team/img.png" alt="Teachers">
                                    </div>
                                    <div class="cont">
                                        <a href="#">
                                            <h6>Late Dr. Amrit Lal Israt</h6>
                                        </a>
                                        <span>Founder</span>
                                    </div>
                                </div>
                                <!-- single teachers -->
                            </div>
                            <div class="col-sm-6">
                                <div class="single-teachers mt-30 text-center">
                                    <div class="image">
                                        <img src="<?php echo base_url()?>assets/img/team/img.png" alt="Teachers">
                                    </div>
                                    <div class="cont">
                                        <a href="#">
                                            <h6>Late Mrs. Deesh Ishrat</h6>
                                        </a>
                                        <span>Founder</span>
                                    </div>
                                </div>
                                <!-- single teachers -->

                            </div>

                        </div>
                        <!-- row -->
                    </div>
                    <!-- teachers -->
                </div>
                <div class="col-lg-12 offset-lg-1">
                    <div class="teachers mt-20">
                        <div class="row">

                            <div class="col-sm-3">
                                <div class="single-teachers mt-30 text-center">
                                    <div class="image">
                                        <img src="<?php echo base_url()?>assets/img/team/img.png" alt="Teachers">
                                    </div>
                                    <div class="cont">
                                        <a href="#">
                                            <h6>Dr. Pradeep 'BABA' Madhok</h6>
                                        </a>
                                        <span>President</span>
                                    </div>
                                </div>
                                <!-- single teachers -->
                            </div>
                            <div class="col-sm-3">
                                <div class="single-teachers mt-30 text-center">
                                    <div class="image">
                                        <img src="<?php echo base_url()?>assets/img/team/img.png" alt="Teachers">
                                    </div>
                                    <div class="cont">
                                        <a href="#">
                                            <h6>Mrs. Pooja Madhok</h6>
                                        </a>
                                        <span>Director</span>
                                    </div>
                                </div>
                                <!-- single teachers -->
                            </div>
                            <div class="col-sm-3">
                                <div class="single-teachers mt-30 text-center">
                                    <div class="image">
                                        <img src="<?php echo base_url()?>assets/img/team/img.png" alt="Teachers">
                                    </div>
                                    <div class="cont">
                                        <a href="#">
                                            <h6>Mr. Maahir Madhok</h6>
                                        </a>
                                        <span>Additional Director</span>
                                    </div>
                                </div>
                                <!-- single teachers -->
                            </div>




                        </div>
                        <!-- row -->
                    </div>
                    <!-- teachers -->
                </div>


            </div>
            <!-- row -->
        </div>
        <!-- container -->
    </section>

    <!--====== TEACHERS PART ENDS ======-->

    <!--====== ABOUT PART START ======-->

    <section id="Section1" class="pt-65">
        <div class="container">
            <div class="row">

                <!-- Awards -->
                <div class="col-lg-4 ">
                    <div class="about-event mt-50">
                        <div class="event-title">
                            <h3>Associates</h3>
                        </div>
                        <!-- event title -->
                        <ul>


                            <li><a href="#"><i class="fa fa-angle-double-right" aria-hidden="true"></i>AZAMGARH</a></li>
                            <br />
                            <li><a href="#"><i class="fa fa-angle-double-right" aria-hidden="true"></i>CHAKIA </a></li>
                            <br />
                            <li><a href="#"><i class="fa fa-angle-double-right" aria-hidden="true"></i>GHAZIPUR </a>
                            </li>
                            <br />
                            <li><a href="#"><i class="fa fa-angle-double-right" aria-hidden="true"></i>JAUNPUR </a></li>
                            <br />
                            <li><a href="#"><i class="fa fa-angle-double-right" aria-hidden="true"></i>RENUKOOT </a>
                            </li>
                            <br />
                            <li><a href="#"><i class="fa fa-angle-double-right" aria-hidden="true"></i>SULTANPUR</a>
                            </li>
                            <br />
                            <li><a href="#"><i class="fa fa-angle-double-right" aria-hidden="true"></i>SAYED
                                    RAJA(CHANDAULI) </a></li>
                            <br />
                            <li><a href="#"><i class="fa fa-angle-double-right" aria-hidden="true"></i>OBRA </a></li>
                            <br />
                            <li><a href="#"><i class="fa fa-angle-double-right" aria-hidden="true"></i>SHAHGANJ</a></li>
                            <br />
                            <li><a href="#"><i class="fa fa-angle-double-right" aria-hidden="true"></i>DILDARNAGAR </a>
                            </li>
                            <br />
                            <li><a href="#"><i class="fa fa-angle-double-right" aria-hidden="true"></i>GANDHINAGAR</a>
                            </li>
                            <br />
                            <li><a href="#"><i class="fa fa-angle-double-right" aria-hidden="true"></i>KUCHMAN</a></li>
                            <br />
                            <li><a href="#"><i class="fa fa-angle-double-right" aria-hidden="true"></i>CHHIMIYA</a></li>


                        </ul>

                    </div>
                    <!-- about event -->
                </div>

                <!-- Blazzers -->
                <div class="col-lg-4">
                    <div class="about-event mt-50">
                        <div class="event-title">
                            <h3>Quick Links</h3>
                        </div>
                        <!-- event title -->
                        <ul>
                            <li>
                                <div class="single-event">

                                    <a href="#">

                                        <h5>Admission Enquiry Form</h5>
                                    </a>

                                </div>
                            </li>
                            <li>
                                <div class="single-event">

                                    <a href="#">
                                        <h5>FeedBack Form</h5>
                                    </a>

                                </div>
                            </li>
                            <li>
                                <div class="single-event">

                                    <a href="#">
                                        <h5>Download Prospectus</h5>
                                    </a>

                                </div>
                            </li>

                            <li>
                                <div class="single-event">

                                    <a href="#">
                                        <h5>Download TC</h5>
                                    </a>

                                </div>
                            </li>

                            <li>
                                <div class="single-event">

                                    <a href="#">
                                        <h5>Photo Gallery</h5>
                                    </a>

                                </div>
                            </li>


                        </ul>
                    </div>
                    <!-- about event -->
                </div>

                <!-- Desk of president -->
                <div class="col-lg-4">
                    <div class="about-event mt-50" style="padding-left: 20px; padding-right: 20px;">
                        <div class="event-title">
                            <h3>Desk Of President</h3>
                        </div>
                        <!-- event title -->
                        <ul>
                            <li>
                                <div class="single-event">
                                    <p style="text-align: justify;">
                                        Dear all,<br />
                                        This is to inform one and all that the DALIMSS Sunbeam School (Dr. Amrit Lal
                                        Ishrat Memorial Sunbeam School) Chaubeypur is not our branch, they are
                                        self-proclaiming our name and goodwill which has been built by the Madhok family
                                        for over 40 years. Dr Amrit Lal Ishrat Memorial Sunbeam Schools was founded in
                                        1997 by our mother Mrs. Deesh Ishrat the founder of Sunbeam Schools in memory of
                                        our father late Dr. Amrit Lal Ishrat. I urge one and all to take note of our
                                        statement that the DALIMSS Chaubeypur is not a part of our schools. We have
                                        already initiated legal process to stop this.

                                    </p>

                                </div>
                            </li>

                        </ul>

                    </div>
                    <!-- about event -->
                </div>

            </div>
            <!-- row -->
        </div>
        <!-- container -->
        <div class="about-bg">
            <img src="<?php echo base_url() ?>assets/images/about/bg-1.html" alt="About">
        </div>
    </section>

    <!--====== ABOUT PART ENDS ======-->




    <!--====== Awards PART START ======-->

    <section id="course-part" class="pt-115 pb-120 gray-bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="section-title pb-45">

                        <h2>Trail Blazers </h2>
                    </div>
                    <!-- section title -->
                </div>
            </div>
            <!-- row -->
            <div class="row course-slide mt-30">
                <div class="col-lg-4">
                    <div class="single-course">
                        <div class="thum">
                            <div class="image">
                                <img src="<?php echo base_url() ?>assets/images/AWARDS/1.png" alt="Course">
                            </div>

                        </div>
                        <div class="cont">

                            <a href="#">
                                <h5>BEST EMERGING CBSE SCHOOL IN U.P.</h5>
                            </a>

                        </div>
                    </div>
                    <!-- single course -->
                </div>
                <div class="col-lg-4">
                    <div class="single-course">
                        <div class="thum">
                            <div class="image">
                                <img src="<?php echo base_url() ?>assets/images/AWARDS/4.png" alt="Course">
                            </div>

                        </div>
                        <div class="cont">

                            <a href="">
                                <h5>Best Hi- Tech Day Boarding Cum-Residential School</h5>
                            </a>

                        </div>
                    </div>
                    <!-- single course -->
                </div>
                <div class="col-lg-4">
                    <div class="single-course">
                        <div class="thum">
                            <div class="image">
                                <img src="<?php echo base_url() ?>assets/images/AWARDS/8.png" alt="Course">
                            </div>

                        </div>
                        <div class="cont">

                            <a href="">
                                <h5>International Education Award for the best Private School in Uttar Pradesh</h5>
                            </a>

                        </div>
                    </div>
                    <!-- single course -->
                </div>
                <div class="col-lg-4">
                    <div class="single-course">
                        <div class="thum">
                            <div class="image">
                                <img src="<?php echo base_url() ?>assets/images/AWARDS/2.png" alt="Course">
                            </div>

                        </div>
                        <div class="cont">

                            <a href="">
                                <h5>Best in Infrastructure to DALIMSS Sunbeam School, Ramkatora, Varanasi</h5>
                            </a>

                        </div>
                    </div>
                    <!-- single course -->
                </div>
                <div class="col-lg-4">
                    <div class="single-course">
                        <div class="thum">
                            <div class="image">
                                <img src="<?php echo base_url() ?>assets/images/AWARDS/6.png" alt="Course">
                            </div>

                        </div>
                        <div class="cont">

                            <a href="">
                                <h5>Best in Innovative Teaching Practices to DALIMSS Sunbeam School, Mohinikunj,
                                    Varanasi </h5>
                            </a>

                        </div>
                    </div>
                    <!-- single course -->
                </div>


                <div class="col-lg-4">
                    <div class="single-course">
                        <div class="thum">
                            <div class="image">
                                <img src="<?php echo base_url() ?>assets/images/AWARDS/3.png" alt="Course">
                            </div>

                        </div>
                        <div class="cont">

                            <a href="">
                                <h5>Best Academic Excellence / Implementing PBL Methods / Special Education School Among
                                    Best CBSE Schools Of Uttar Pradesh </h5>
                            </a>

                        </div>
                    </div>
                    <!-- single course -->
                </div>


            </div>
            <!-- course slide -->
        </div>
        <!-- container -->
    </section>

    <!--====== COURSE PART ENDS ======-->







    <!--====== VIDEO FEATURE PART START ======-->

    <section id="video-feature" class="bg_cover pt-60 pb-110" style="background-image: url(<?php echo base_url() ?>assets/images/School_Back.jpg)">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 order-last order-lg-first">
                    <div class="video text-lg-left text-center pt-50">
                        <a class="Video-popup" href="https://www.youtube.com/watch?v=mc-u6wsPJtw"><i
                                class="fa fa-play"></i></a>
                    </div>
                    <!-- row -->
                </div>
                <div class="col-lg-5 offset-lg-1 order-first order-lg-last">
                    <div class="feature pt-50">
                        <div class="feature-title">
                            <h3>Our Facilities</h3>
                        </div>
                        <ul>
                            <li>
                                <div class="single-feature">
                                    .

                                    <div class="icon">
                                        <img src="<?php echo base_url() ?>assets/images/all-icon/f-1.png" alt="icon">
                                    </div>
                                    <div class="cont">
                                        <h4>State of The Art Facilities</h4>

                                    </div>
                                </div>
                                <!-- single feature -->
                            </li>
                            <li>
                                <div class="single-feature">
                                    <div class="icon">
                                        <img src="<?php echo base_url() ?>assets/images/all-icon/f-2.png" alt="icon">
                                    </div>
                                    <div class="cont">
                                        <h4>Trained Facilitators</h4>

                                    </div>
                                </div>
                                <!-- single feature -->
                            </li>
                            <li>
                                <div class="single-feature">
                                    <div class="icon">
                                        <img src="<?php echo base_url() ?>assets/images/all-icon/f-1.png" alt="icon">
                                    </div>
                                    <div class="cont">
                                        <h4>State Of the art Library</h4>

                                    </div>
                                </div>
                                <!-- single feature -->




                            </li>

                            <li>
                                <div class="single-feature">
                                    <div class="icon">
                                        <img src="<?php echo base_url() ?>assets/images/all-icon/f-1.png" alt="icon">
                                    </div>
                                    <div class="cont">
                                        <h4>Boarding School</h4>

                                    </div>
                                </div>
                                <!-- single feature -->

                            </li>


                            <li>
                                <div class="single-feature">
                                    <div class="icon">
                                        <img src="<?php echo base_url() ?>assets/images/all-icon/f-1.png" alt="icon">
                                    </div>
                                    <div class="cont">
                                        <h4>World Class Lab</h4>

                                    </div>
                                </div>
                                <!-- single feature -->

                            </li>


                            <li>
                                <div class="single-feature">
                                    <div class="icon">
                                        <img src="<?php echo base_url() ?>assets/images/all-icon/f-1.png" alt="icon">
                                    </div>
                                    <div class="cont">
                                        <h4>Lush Green Campus</h4>

                                    </div>
                                </div>
                                <!-- single feature -->




                            </li>




                        </ul>
                    </div>
                    <!-- feature -->
                </div>
            </div>
            <!-- row -->
        </div>
        <!-- container -->
        <div class="feature-bg"></div>
        <!-- feature bg -->
    </section>

    <!--====== VIDEO FEATURE PART ENDS ======-->




    <section id="Section3" class="pt-115 pb-120 gray-bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="section-title pb-45">

                        <h2>Growing by Leaps and Bounds </h2>
                    </div>
                    <!-- section title -->
                </div>
            </div>
            <!-- row -->

            <div class="row ">

                <div class="col-md-3 col-sm-3 col-12">
                    <div class="achievement-item">
                        <i class="icon flaticon-student"></i>
                        <h4><span class="counter">25000</span><span>+</span></h4>
                        <h5>Total Students</h5>
                    </div>
                    <!-- achievement item -->
                </div>
                <div class="col-md-3 col-sm-3 col-12">
                    <div class="achievement-item">
                        <i class="icon flaticon-people"></i>
                        <h4><span class="counter">2800</span><span>+</span> </h4>
                        <h5>Educators</h5>
                    </div>
                    <!-- achievement item -->
                </div>
                <div class="col-md-3 col-sm-3 col-12">
                    <div class="achievement-item">
                        <i class="icon flaticon-construction"></i>
                        <h4><span class="counter">20</span><span>+</span> </h4>
                        <h5>Campus</h5>
                    </div>
                    <!-- achievement item -->
                </div>
                <div class="col-md-3 col-sm-3 col-12">
                    <div class="achievement-item">
                        <i class="icon flaticon-world"></i>
                        <h4><span class="counter">50</span><span>+</span> </h4>
                        <h5>Awards</h5>
                    </div>
                    <!-- achievement item -->
                </div>
            </div>


            <!-- course slide -->
        </div>
        <!-- container -->
    </section>







    <!-- Achievements End here -->

    <!--====== TEASTIMONIAL PART START ======-->

    <section id="testimonial" class="bg_cover pt-115 pb-115" data-overlay="8"
        style="background-image: url(<?php echo base_url() ?>assets/images/bg-2.jpg)">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="section-title pb-40">
                        <h5>Testimonial</h5>
                        <h2>What our parents Say</h2>
                    </div>
                    <!-- section title -->
                </div>
            </div>
            <!-- row -->
            <div class="row testimonial-slide mt-40">
                <div class="col-lg-6">
                    <div class="single-testimonial">
                        <div class="testimonial-thum">
                            <img src="<?php echo base_url() ?>assets/images/testimonial/3.png" alt="Testimonial">
                            <div class="quote">
                                <i class="fa fa-quote-right"></i>
                            </div>
                        </div>
                        <div class="testimonial-cont">
                            <p>Hello, “Dalimss Toddlers” is one of the reputed & known school of the city,Varanasi. I am
                                fortunate that my daughter is being educated here. This school gives all the necessary
                                lessons to the child to which they have to be aware in day-to-day life. Teachers, here
                                are very helpful and supportive to the parents as well as to the students. They
                                understand the child in their way. They teach the student in different ways like
                                playing, entertaining or visually also. They make the child active and self dependent
                                also. </p>
                            <h6>Dr. Pooja Srivastava </h6>

                        </div>
                    </div>
                    <!-- single testimonial -->
                </div>
                <div class="col-lg-6">
                    <div class="single-testimonial">
                        <div class="testimonial-thum">
                            <img src="<?php echo base_url() ?>assets/images/testimonial/4.png" alt="Testimonial">
                            <div class="quote">
                                <i class="fa fa-quote-right"></i>
                            </div>
                        </div>
                        <div class="testimonial-cont">
                            <p>My daughter is studying in this school from class VII earlier she had stage fear, but
                                after coming in this school she is able to overcome stage fear. She can express her
                                thoughts and ideas freely anywhere and in front of anyone. DALIMSS SUNBEAM WORLD SCHOOL
                                Paharia is responsible for overall development of my child. The teachers are very
                                helpful and encouraging. I am fully satisfied by the school and progress of my daughter.
                                I would like to give the credit of her success to the complete teaching staff. </p>
                            <h6>Mr. Anil Singh</h6>

                        </div>
                    </div>
                    <!-- single testimonial -->
                </div>
                <div class="col-lg-6">
                    <div class="single-testimonial">
                        <div class="testimonial-thum">
                            <img src="<?php echo base_url() ?>assets/images/testimonial/1.jpg" alt="Testimonial">
                            <div class="quote">
                                <i class="fa fa-quote-right"></i>
                            </div>
                        </div>
                        <div class="testimonial-cont">
                            <p>I am Dr. Meraj Bano.Two of my kids are studying at “ Dalimss Toddlers, Ramkatora”.One in
                                Playgroup and other in U.K.G. I have a very good experience about this school regarding
                                teaching and other caring concern of my children. Other than teaching books and subjects
                                , this school also gives a lot of etiquette sessions, good fun learning activities to
                                kids ,which I like most when comparing to other schools. School digitalization through
                                internet is also very favorable for kids and parents.</p>
                            <h6>Dr. Meraj Bano </h6>

                        </div>
                    </div>
                    <!-- single testimonial -->
                </div>

                <div class="col-lg-6">
                    <div class="single-testimonial">
                        <div class="testimonial-thum">
                            <img src="<?php echo base_url() ?>assets/images/testimonial/2.png" alt="Testimonial">
                            <div class="quote">
                                <i class="fa fa-quote-right"></i>
                            </div>
                        </div>
                        <div class="testimonial-cont">
                            <p>The best school in Varanasi, run by an incredibly, loving warm team of teachers and staff
                                members. The academics of the school is too good. Everyday my son “Vinayak” is very
                                excited to go to school to learn new things. In the last 2 years my son learns a lot and
                                made a good Again I would like to say “Sunbeam World school” is the best school in our
                                area. </p>
                            <h6>Mrs. Anshu Seth</h6>

                        </div>
                    </div>
                    <!-- single testimonial -->
                </div>

            </div>
            <!-- testimonial slide -->
        </div>
        <!-- container -->
    </section>

    <!--====== TEASTIMONIAL PART ENDS ======-->



    <!--====== PATNAR LOGO PART START ======-->

    <div id="patnar-logo" class="pt-40 pb-80 gray-bg">
        <div class="container">
            <div class="section-header">
                <h3>Educational Partners</h3>

            </div>
            <div class="row patnar-slide">
                <div class="col-lg-12">
                    <div class="single-patnar text-center mt-40">
                        <img src="<?php echo base_url()?>assets/img/brand/asset.jpg" alt="Logo">
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="single-patnar text-center mt-40">
                        <img src="<?php echo base_url()?>assets/img/brand/british_council.jpg" alt="Logo">
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="single-patnar text-center mt-40">
                        <img src="<?php echo base_url()?>assets/img/brand/educational1.jpg" alt="Logo">
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="single-patnar text-center mt-40">
                        <img src="<?php echo base_url()?>assets/img/brand/Fcn%20Png.png" alt="Logo">
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="single-patnar text-center mt-40">
                        <img src="<?php echo base_url()?>assets/img/brand/macmillan1.jpg" alt="Logo">
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="single-patnar text-center mt-40">
                        <img src="<?php echo base_url()?>assets/img/brand/prim-plus.jpg" alt="Logo">
                    </div>
                </div>

                <div class="col-lg-12">
                    <div class="single-patnar text-center mt-40">
                        <img src="<?php echo base_url()?>assets/img/brand/sahodya_school_logo.jpg" alt="Logo">
                    </div>
                </div>

            </div>
            <!-- row -->
        </div>
        <!-- container -->
    </div>

    <!--====== PATNAR LOGO PART ENDS ======-->






    <script type="text/javascript" src='<?php echo base_url()?>assets/js/jquery-1.8.3.min.js'></script>
    <script type="text/javascript" src='<?php echo base_url()?>assets/js/bootstrap1.min.js'>
    </script>

    <!-- Bootstrap -->
    <!-- Modal Popup -->






    <script type="text/javascript">
    //<![CDATA[
    ShowPopup('Welcome to DALIMSS Sunbeam group of Schools & Hostel', '');
    Sys.Application.initialize();
    //]]>
    </script>
</form>